module.exports = {
  lintOnSave: undefined,
  productionSourceMap: false, // 取消源代码映射（防止源代码暴露在浏览器控制台的source中的top/webpack://目录下）
}